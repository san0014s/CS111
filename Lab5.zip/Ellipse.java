
public class Ellipse extends GraphicObject {
	// data members
	private double semiMajorAxis;
	private double semiMinorAxis;

	// operations
	public Ellipse(double newX, double newY, int red, int green, int blue, double newSemiMajor, double newSemiMinor) {
		super(newX, newY, red, green, blue);

		semiMajorAxis = newSemiMajor;
		semiMinorAxis = newSemiMinor;

	}

	@Override
	public void draw() {
		StdDraw.setPenColor(getColor());
		StdDraw.filledEllipse(getX(), getY(), semiMajorAxis, semiMinorAxis);

	}

	@Override
	public double calculateArea() {
		return Math.PI * semiMajorAxis * semiMinorAxis;
	}

	@Override
	public double calculatePerimeter() {
		return 0;
	}

}