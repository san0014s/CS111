import java.awt.Color;

public abstract class GraphicObject {
	//data member
	private double x;
	private double y;
	private Color color;

	//operations
	public GraphicObject (double newX,  double newY, int red, int green,  int blue) {
		x = newX;
		y = newY;
		color = new Color(red, green, blue);
	}
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public Color getColor() {
		return color;
	}

	public String toString() {
		return getClass() + " x: " + getX() + " Y: " + getY() + " Red: " + getColor().getRed() + " Green: "+ getColor().getGreen() + " Blue: " + getColor().getBlue();
	}

	public abstract void draw();

	public abstract double calculateArea();

	public abstract double calculatePerimeter();

}