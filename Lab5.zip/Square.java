public class Square extends GraphicObject {
	//data members
	private double sideLength;

	//operations
	public Square(double newX,  double newY, int red, int green,  int blue, double sideLength) {
		super(newX, newY, red, green, blue);


	}

	@Override
	public void draw() {
		StdDraw.setPenColor(getColor());
		StdDraw.filledSquare(getX(), getY(), sideLength);
	}

	@Override
	public double calculateArea() {
		return Math.pow(2*sideLength, 2);

	}

	@Override
	public double calculatePerimeter() {
		return 4*(2*sideLength);
	}

}