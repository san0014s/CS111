
public class Circle extends GraphicObject {
	//data member
	private double radius;

	//operations
	public Circle(double newX,  double newY, int red, int green,  int blue ,double newRadius) {
		super(newX, newY, red, green, blue);

		radius = newRadius;
	}

	@Override
	public void draw() {
		StdDraw.setPenColor(getColor());
		StdDraw.filledCircle(getX(), getY(), radius);
	}

	@Override
	public double calculateArea() {
		return Math.PI * Math.pow(radius, 2);
	}

	@Override
	public double calculatePerimeter() {
		return 2 * Math.PI * radius;
	}

}
