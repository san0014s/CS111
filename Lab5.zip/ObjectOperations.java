import java.util.Scanner;

public class ObjectOperations {

	//operations
	public static void fillArray( GraphicObject[]  objectList,  Scanner filename) {
		int index = 0;
		while(filename.hasNextLine()) {
			String shape = filename.next();
			double x = filename.nextDouble();
			double y = filename.nextDouble();
			int red = filename.nextInt();
			int green = filename.nextInt();
			int blue = filename.nextInt();
			if(shape.equals("C")){
				double radius = filename.nextDouble();
				Circle c = new Circle(x,y, red, green, blue, radius);
				objectList[index] = c;
			}

			if(shape.equals("R")) {
				double length = filename.nextDouble();
				double width = filename.nextDouble();
				Rectangle r = new Rectangle(x, y, red, green, blue, length, width);
				objectList[index] = r;
			}

			if(shape.equals("S")) {
				double sideLength = filename.nextDouble();
				Square s = new Square(x, y, red, green, blue, sideLength);
				objectList[index] = s;
			}

			if(shape.equals("E")) {
				double semiMinorAxis = filename.nextDouble();
				double semiMajorAxis = filename.nextDouble();
				Ellipse e = new Ellipse(x, y, red, green, blue, semiMajorAxis, semiMinorAxis);
				objectList[index] = e;

			}
			index++;
			if(filename.hasNextLine()) {
				filename.nextLine();
			}
		}

	}
	public static void drawList( GraphicObject[] objectList) {
		for(GraphicObject g1 : objectList)
			g1.draw();
	}

	public static void printList( GraphicObject[] objectList) {
		for(GraphicObject g1 : objectList)
			System.out.println(g1);
	}



}