import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {

		GraphicObject[] objectList = new GraphicObject[20];

		StdDraw.setCanvasSize( 1000,1000);
		StdDraw.setXscale(0, 1000);
		StdDraw.setYscale(0, 1000);
		StdDraw.setPenRadius(0.02);


		File textFile;
		Scanner userInput = new Scanner(System.in);
		Scanner fileName = null;
		System.out.println("Please enter the correct filename.");
		textFile = new File(userInput.nextLine());
		boolean flag = false;
		while(!flag) {
			try {
				fileName = new Scanner(textFile);
				ObjectOperations.fillArray(objectList, fileName);
				ObjectOperations.drawList(objectList);
				ObjectOperations.printList(objectList);
				userInput.close();
				flag = true;

			} catch (FileNotFoundException e) {
				System.out.println("The file has not been found, please try again");
				textFile = new File(userInput.nextLine());

				flag = false;
			}

		}

	}


}
