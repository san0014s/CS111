public class Rectangle extends GraphicObject {
	//data member
	double length;
	double width;

	//operations
	public Rectangle(double newX,  double newY, int red, int green,  int blue, double newLength, double newWidth) {
		super(newX, newY, red, green, blue);

		length = newLength;
		width = newWidth;

	}

	@Override
	public void draw() {
		StdDraw.setPenColor(getColor());
		StdDraw.filledRectangle(getX(), getY(), length, width);

	}

	@Override
	public double calculateArea() {
		return 2* (width * length);
	}

	@Override
	public double calculatePerimeter() {
		return  2 * (2 *(length + width));
	}

}