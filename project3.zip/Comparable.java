
public interface Comparable {

	/* 
	 * compareTo():   This method returns the current number of items in the bag
	 * 
	 */
	public int compareTo(Employee another);
}
