
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Tester {

	private static ArrayList<Employee> mainEmploy = new ArrayList(30);

	public Tester() {
	}

	public static void main(String[] args) {
		//call files
		readEmployeeData();
		sortEmployee();
		calCulatePay();
		printReport();
	}

	public static void readEmployeeData() {
		// employeeData.txt reminder
		int index = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter a valid employee data file.");
		String line;
		String[] lineData;
		String fileName = input.nextLine();
		try {
			//should hopefully read the file
			File filePath = new File(fileName);
			BufferedReader reader = new BufferedReader(new FileReader(filePath));
			//            line = reader.readLine();
			while ((line = reader.readLine()) != null) {
				lineData = line.split("\\s+");
				if (lineData[0].equals("C")) {
					//current sales = 8
					//base salary = 5
					float commissionSales
					= Float.parseFloat(lineData[8])
					- Float.parseFloat(lineData[5]);
					CommissionEmployees object
					= new CommissionEmployees(lineData[0], Integer.parseInt(lineData[1]), lineData[2], lineData[3], lineData[4], Float.parseFloat(lineData[6]), Float.parseFloat(lineData[7]));
					object.setCommissionSales(index);
					mainEmploy.add(object);
				} else if (lineData[0].equals("S")) {
					mainEmploy.add(new Salaried(lineData[0], Integer.parseInt(lineData[1]), lineData[2], lineData[3], lineData[4], Float.parseFloat(lineData[5])));
				} else if (lineData[0].equals("H")) {
					float hoursworked = Float.parseFloat(lineData[7]);
					boolean overtime = lineData[6].equals("Y") ? true : false;//wildcard
					Hourly object = new Hourly(lineData[0], Integer.parseInt(lineData[1]), lineData[2], lineData[3], lineData[4], Float.parseFloat(lineData[5]), overtime);
					object.setHoursWorked(hoursworked);
					mainEmploy.add(object);
				}
				index++;
			}
		} catch (IOException e) {
			//should keep asking if type incorrectly
			readEmployeeData();
		}

	}

	public static void sortEmployee() {
		Employee temp;

		for (int i = 0; i < mainEmploy.size(); i++) {
			for (int j = 0; j < mainEmploy.size() - 1; j++) {
				if (mainEmploy.get(j).compareTo(mainEmploy.get(j + 1)) == 1) {
					temp = mainEmploy.get(j);
					mainEmploy.set(j, mainEmploy.get(j + 1));
					mainEmploy.set(j + 1, temp);
				}
			}
		}
	}

	private static void calCulatePay() {
		for (int i = 0; i < mainEmploy.size(); i++) {
			mainEmploy.get(i).calculatePay();
		}
	}

	public static void printReport() {
		System.out.println("commission  Employee");
		System.out.println("First Name\tLast Name\tTitle\tEmployee ID\t"
				+ "Commission Rate\tSalary\tTotal salary");
		int i = 0;
		for (; i < mainEmploy.size(); i++) {
			if (mainEmploy.get(i).getType().equals("C")) {
				mainEmploy.get(i).print();
				//2.	add this employees total Pay to the total pay for all employees of this type
				for (int j = i + 1; j < mainEmploy.size(); j++) {
					if (mainEmploy.get(j).getType().equals("C")) {
						mainEmploy.get(j).setTotalPay(mainEmploy.get(j).getTotalPay()
								+ mainEmploy.get(i).getTotalPay());

					}
				}
			} else {
				break;
			}
		}
		System.out.println("total pay  " + mainEmploy.get(i - 1).getTotalPay());
		System.out.println("\n\n\n");
		System.out.println("hourly employees");
		System.out.println("First Name\tLast Name\tTitle\tEmployee ID\tTotalPay");

		//////////////////////
		for (; i < mainEmploy.size(); i++) {
			if (mainEmploy.get(i).getType().equals("H")) {
				mainEmploy.get(i).print();
				for (int j = i + 1; j < mainEmploy.size(); j++) {
					if (mainEmploy.get(j).getType().equals("H")) {
						mainEmploy.get(j).setTotalPay(mainEmploy.get(j).getTotalPay()
								+ mainEmploy.get(i).getTotalPay());

					}
				}
			} else {
				break;
			}
		}
		//bunch of print statements
		System.out.println("total pay  " + mainEmploy.get(i - 1).getTotalPay());
		System.out.println("\n\n\n");
		System.out.println("salaried employees");
		System.out.println("First Name\tLast Name\tTitle\tEmployee ID\tSalary\tTotalPay");
		///////////////
		for (; i < mainEmploy.size(); i++) {
			if (mainEmploy.get(i).getType().equals("S")) {

				mainEmploy.get(i).print();
				for (int j = i + 1; j < mainEmploy.size(); j++) {
					if (mainEmploy.get(j).getType().equals("S")) {
						mainEmploy.get(j).setTotalPay(mainEmploy.get(j).getTotalPay()
								+ mainEmploy.get(i).getTotalPay());

					}
				}
			}
		}
		System.out.println("total pay  " + mainEmploy.get(mainEmploy.size() - 1).getTotalPay());
		System.out.println("\n\n\n");
	}
}
