
public class Salaried extends Employee {

	private float Salary;
	
	public Salaried(String type , int id , String firstName, String lastName, String title , float Salary) {
                super(id, firstName, lastName, title, type);
		this.Salary=Salary;
	}


	public float getSalary() {
		return Salary;
	}

	
	public void setSalary(float Salary) {
		this.Salary = Salary;
	}


	@Override
	public void calculatePay() {
            
                this.totalPay =  (this.Salary / 24);	
	}


	@Override
	public void print() {
		System.out.println(
                        getFirstName() + "\t\t\t" + getLastName()+"\t\t\t"+
                        getTitle()+"\t\t\t"+getid()+"\t\t\t"+
                        "\t\t\t"+getSalary()+"\t\t\t"+getTotalPay());
	}
	
	
}
