
public class CommissionEmployees extends Employee {

    private float Salary;
    // percentage of sales, earned as commission
    private float commissionRate;
    // sales this pay period
    private float commissionSales;
    private float baseSalary;
    private float currentSales;
    // This is the amount of sales an employee must earn before
    // they are eligible to earn commission, for example an employee
    // might have to sell $15000 in products before earning 
    // commission. if they sell less than $15000 they earn nothing
    // if they sell $20000 then they earn commission on $5000

    private float threshold;

    public CommissionEmployees(String type, int id , String firstName, String lastName, String title, float commissionRate,float threshold) {

        super(id, firstName, lastName, title, type);
        this.threshold = threshold;
        this.commissionRate = commissionRate;
    }

    public float getCommissionSales() {
        return commissionSales;
    }

    public float getSalary() {
        return Salary;
    }

    public float getCommissionRate() {
        return commissionRate;
    }

    public float getThreshold() {
        return threshold;
    }

    public void setCommissionSales(float commissionSales) {
        this.commissionSales = commissionSales;
    }

    @Override
    public void calculatePay() {
        if (this.commissionSales > this.threshold) {
            this.totalPay = (this.Salary / 24) + ((this.commissionSales - this.threshold) * this.commissionRate);

        } else {
            this.totalPay = (this.Salary / 24);
        }
    }

    @Override
    public void print() {
        System.out.println(
                getFirstName() + "\t\t\t" + getLastName()+"\t\t\t"+
                        getTitle()+"\t\t\t"+getid()+"\t\t\t"+getCommissionRate()+
                        "\t\t\t"+getSalary()+"\t\t\t"+getTotalPay());
    }

}
