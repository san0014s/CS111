public abstract class Employee implements Comparable {

    private int id;
    private String firstName;
    private String lastName;
    private String Title;
    float totalPay;
    private String type; //the type of employee,

    public Employee(int newid, String newFirstName, String newLastName, String newTitle, String newtype) {
        this.id = newid;
        this.firstName = newFirstName;
        this.lastName = newLastName;
        this.Title = newTitle;
        this.type = newtype;
    }

    public int getid() {
        return this.id;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getTitle() {
        return this.Title;
    }

    public float getTotalPay() {
        return this.totalPay;
    }

    public void setTotalPay(float totalPay) {
        this.totalPay = totalPay;
    }

    public String getType() {
        return this.type;
    }

    public abstract void calculatePay();

    public abstract void print();

    public int compareTo(Employee another) {
        if(this.type.equals(another.type)){
            if(this.id == another.id)
                return 0;
            else if (this.id > another.id)
                return 1;
            else
                return -1;
        }
        else if (this.type.compareTo(another.type) < 0)
            return -1;
        
        return 1;

    }
	
}//end of class
