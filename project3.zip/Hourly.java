
public class Hourly extends Employee {
	private float hoursWorked;
	private float hourlyRate;
	private boolean overtimeEligible;
	public Hourly(String type, int id ,String firstName, String lastName,String title , 
                float hourlyRate , boolean overtimeEligible) {
                        super(id, firstName, lastName, title, type);
			this.hourlyRate = hourlyRate;
			this.overtimeEligible = overtimeEligible;
	}


	public float getHoursWorked() {
		return this.hoursWorked;
	}

	
	public void setHoursWorked(float hoursWorked) {
		this.hoursWorked = hoursWorked;
	}


	public float getHourlyRate() {
		return this.hourlyRate;
	}


	public boolean getOvertimeEligible() {
		return this.overtimeEligible;
	}

	@Override
	public void calculatePay() {
		if(!this.overtimeEligible) {
			this.totalPay = this.hoursWorked * this.hourlyRate;
		}
                else{
                    if( this.hoursWorked <= 80){
                        this.totalPay = this.hourlyRate;
                    }
                    else{
                        this.totalPay = 1.5f*this.hourlyRate;
                    }
                }
	}

	@Override
	public void print() {
		System.out.println(
                getFirstName() + "\t\t\t" + getLastName()+"\t\t\t"+
                        getTitle()+"\t\t\t"+getid()+"\t\t\t"+getTotalPay());
		
		
	}

	
}

